package main

import (
	"fmt"
	"html/template"
	"net/http"
	"path"
	//	"strings"
	//	"time"
)

func handle(w http.ResponseWriter, r *http.Request) {
	// You might want to move ParseGlob outside of handle so it doesn't
	// re-parse on every http request.
	tmpl, err := template.ParseGlob("templates/*")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	name := ""
	if r.URL.Path == "/" {
		name = "magpies.html"
	} else {
		name = path.Base(r.URL.Path)
	}
	type Magpie struct {
		Title       string
		Description string
	}

	/*
		data := struct{
			Time time.Time
		}{
			Time: time.Now(),
		}*/
	data := Magpie{
		Title:       "Magpies",
		Description: "Magpies are fascinating birds belonging to the family Corvidae, which also includes crows and ravens."}
	if err := tmpl.ExecuteTemplate(w, name, data); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		fmt.Println("error", err)
	}
}

func main() {
	fmt.Println("http server up!")
	/*http.Handle(
		"/static/",
		http.StripPrefix(
			"/static/",
			http.FileServer(http.Dir("static")),
		),
	)*/
	http.HandleFunc("/", handle)
	http.ListenAndServe(":80", nil)
}
